Here is a very simple application that lets the user change his name. However, there is some bug in this code. 
Whenever the user writes something into input, the change is not reflected in the welcome header.

Another developer was able to isolate the bug and wrote a test case that simulates the bug. See `src/app/app.spec.js` for test case details. 

Your job is to find the bug and fix it. The only file that should be changed is `src/app/app.js` file. You can always build the project to see if your fix is working.

Good luck!

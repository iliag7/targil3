'use strict';


  var app = angular.module('angularScopesBug', [])
  app.controller("WelcomeController", function ($scope,$rootScope) {
    $scope.name = 'Anonymous';
	//console.log( $scope);

    $scope.getName = function() {
      return $scope.name;
    };
	
  })
 app.controller("EditingController", function($scope,$rootScope) {
    $scope.editMode = false;
    $scope.changeName = function() {
		$scope.editMode = true;
		//console.log($scope.name);
	   //return $scope.name;
    };
    $scope.closeEditor = function() {
      $scope.editMode = false;
    };
	
	$scope.$watch('name', function (newValue, oldValue,) {
		//console.log(val);
		console.log(newValue);
        $scope.name = newValue; 
		//return  $scope.name;
    });
  })
  app.directive("nameEditor", function () {
    return {
      template: 'Write your name: <input type="text" ng-model="name">'
    };
  });

